import React, { Fragment } from 'react'

import { Helmet } from 'react-helmet'

import Navbar from '../components/navbar'
import Hero from '../components/hero'
import Features1 from '../components/features1'
import CTA from '../components/cta'
import Pricing from '../components/pricing'
import Steps from '../components/steps'
import Testimonial from '../components/testimonial'
import Contact from '../components/contact'
import Footer from '../components/footer'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container1">
      <Helmet>
        <title>Spotless Hungry Crocodile</title>
      </Helmet>
      <Navbar></Navbar>
      <Hero image1Src="https://images.unsplash.com/photo-1734216736262-dcb57cf50ca9?ixid=M3w5MTMyMXwwfDF8YWxsfDV8fHx8fHx8fDE3MzUwMTY0MzB8&amp;ixlib=rb-4.0.3&amp;w=1500"></Hero>
      <div className="home-container2">
        <div className="home-container3">
          <img
            src="https://images.unsplash.com/photo-1484882918957-e9f6567be3c8?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w5MTMyMXwwfDF8c2VhcmNofDM4fHxidWlsZGluZ3xlbnwwfHx8fDE3MzUwMTc1OTN8MA&amp;ixlib=rb-4.0.3&amp;q=80&amp;w=400"
            alt="image"
            className="home-image1"
          />
          <div className="home-container4"></div>
        </div>
        <img
          src="https://images.unsplash.com/photo-1534415378365-701353a65fed?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w5MTMyMXwwfDF8c2VhcmNofDIzfHxidWlsZGluZ3xlbnwwfHx8fDE3MzUwMTc1ODZ8MA&amp;ixlib=rb-4.0.3&amp;q=80&amp;w=400"
          alt="image"
          className="home-image2"
        />
      </div>
      <Features1></Features1>
      <CTA
        heading1="do you have pending payments?"
        content1="Experience a user-friendly  design for payment-related activities on our website."
      ></CTA>
      <Pricing
        heading1="Pricing plan"
        content2="Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
        plan1Price="₹25,000"
        plan1Feature1="Frontend Design for Payment Interface"
        plan1Feature2="Work Update System for Workers"
        text={
          <Fragment>
            <span className="home-text10"></span>
          </Fragment>
        }
        text1={
          <Fragment>
            <span className="home-text11">Text</span>
          </Fragment>
        }
        text2={
          <Fragment>
            <span className="home-text12">
              <span>Features: Consultation for furniture arrangement</span>
              <br></br>
              <span>Color palette suggestions</span>
              <br></br>
              <span>Basic floor plan design</span>
              <br></br>
              <span>1 revision</span>
              <br></br>
              <span>Timeline: 7 days</span>
            </span>
          </Fragment>
        }
        plan2="Standard Plan"
        plan2Price="₹50,000"
        text3={
          <Fragment>
            <span className="home-text22">
              <span>Features: Full room furniture arrangement</span>
              <br></br>
              <span>Color palette and material selection</span>
              <br></br>
              <span>2D layout and basic 3D rendering</span>
              <br></br>
              <span>Up to 3 revisions</span>
              <br></br>
              <span>Assistance with decor shopping</span>
              <br></br>
              <span>Timeline: 14 days</span>
            </span>
          </Fragment>
        }
        plan3="Premium Plan"
        plan3Price="₹1,00,000"
        text4={
          <Fragment>
            <span className="home-text34">
              <span>Features:</span>
              <br></br>
              <br></br>
              <span>Complete home interior design</span>
              <br></br>
              <span>High-quality 3D visualization</span>
              <br></br>
              <span>Lighting and decor consultation</span>
              <br></br>
              <span>Custom furniture recommendations</span>
              <br></br>
              <span>Unlimited revisions within 30 days</span>
              <br></br>
              <span>On-site supervision for installation</span>
              <br></br>
              <span>Timeline: 30 days</span>
              <br></br>
            </span>
          </Fragment>
        }
      ></Pricing>
      <Steps></Steps>
      <Testimonial></Testimonial>
      <Contact
        email1="mahiconstructions@gmail.com"
        phone1="+917509891712\n"
        address1="kachna, Raipur, 492014\n"
      ></Contact>
      <Footer></Footer>
    </div>
  )
}

export default Home
