import React from 'react'

import PropTypes from 'prop-types'

import './testimonial.css'

const Testimonial = (props) => {
  return (
    <div className="thq-section-padding">
      <div className="testimonial-max-width thq-section-max-width">
        <div className="testimonial-container1">
          <h2 className="thq-heading-2">{props.heading1}</h2>
          <span className="testimonial-text2 thq-body-small">
            {props.content1}
          </span>
        </div>
        <div className="thq-grid-2">
          <div className="thq-animated-card-bg-2">
            <div className="thq-animated-card-bg-1">
              <div data-animated="true" className="thq-card testimonial-card1">
                <div className="testimonial-container3">
                  <div className="testimonial-container4"></div>
                </div>
              </div>
            </div>
          </div>
          <div className="testimonial-accent2-bg2 thq-animated-card-bg-2"></div>
          <div className="thq-animated-card-bg-2">
            <div className="testimonial-accent1-bg2 thq-animated-card-bg-1"></div>
          </div>
          <div className="thq-animated-card-bg-2">
            <div className="thq-animated-card-bg-1">
              <div data-animated="true" className="thq-card testimonial-card2">
                <div className="testimonial-container5">
                  <div className="testimonial-container6"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

Testimonial.defaultProps = {
  content1:
    'Read what our clients have to say about their experience with Mahi Constructions.',
  heading1: 'Testimonials',
}

Testimonial.propTypes = {
  content1: PropTypes.string,
  heading1: PropTypes.string,
}

export default Testimonial
